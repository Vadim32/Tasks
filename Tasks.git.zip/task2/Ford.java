package demidov.hh.tasks.task2;

public class Ford implements Car {

	
	public int amortization() {
		// TODO Auto-generated method stub
	      return 5;
	    }
	 
	    public int repair() {
	    	// TODO Auto-generated method stub
	      return 100;
	    }
	
}
