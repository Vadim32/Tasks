package demidov.hh.tasks.task2;

public class Opel implements Car{

	public int amortization() {
		// TODO Auto-generated method stub
		return 10;
	}

	public int repair() {
		// TODO Auto-generated method stub
		return 200;
	}

}
