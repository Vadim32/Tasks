package demidov.hh.tasks.task2;

public abstract interface Car {

	  public abstract int amortization();
	  public abstract int repair();
	
}
